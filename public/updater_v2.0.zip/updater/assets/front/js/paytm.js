(function ($) {
    "use strict";
    document.f1.submit();
})(jQuery); 
