<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserPermission
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        if(Auth::check()){
          $id = auth()->id();
          $me = User::find($id);
          if( !$me->gender || !$me->dob || !$me->religion){
            return redirect()->route('register');
          }
          if(!$me->gradient_name || !$me->relation_with_contact){
            return redirect()->route('user.physical');
          }
          if(!$me->pertnerPreference){
            
            return redirect()->route('register.step7');
          }
          return $next($request);
        }
        return $next($request);
    }
}
