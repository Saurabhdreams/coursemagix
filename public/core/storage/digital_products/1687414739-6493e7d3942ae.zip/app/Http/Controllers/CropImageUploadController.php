<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Image;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
class CropImageUploadController extends Controller
{
    public function index()
    {
     return view('image-crop');
    }

    public function store(Request $request)
    {
        return $request->all();
 
        $file = $request->img;
        $originalName = $file->getClientOriginalName();
        Storage::disk('upload')->put('hukkahua/' . $originalName, File::get($file));

         $saveFile = new Image;
         $saveFile->title = "hulu";
         $saveFile->save();

        return response()->json(['success'=>'Crop Image Saved/Uploaded Successfully using jQuery and Ajax In Laravel']);
    }
}
