<?php

namespace App\Http\Controllers;

use App\Models\UserSettingField;
use App\Models\UserSettingItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OptionSettingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        request()->session()->forget(['lsbm', 'lsbsm']);
        request()->session()->put(['lsbm' => 'website', 'lsbsm' => 'optionPage']);

        $optionFields = UserSettingField::whereIn('id',[1,2,3,4,11,14,15,17,18,20,21,25,26,27,28,29,30,32,31,33,34,35,38,40,44,46,48])->orderBy('id','asc')->get();
        return view('admin.option.index',compact('optionFields'));
    }

    public function optionItemCreate(Request $request)
    {
        $userSettingsFields = UserSettingField::find($request->id);
        return view('admin.option.create',compact('userSettingsFields'));
    }

    public function optionItemSave(Request $request,$id)
    {
       $request->validate([
        'title' => 'required'
       ]);

       $uF = new UserSettingItem();
       $uF->title = $request->title;
       $uF->drag_id = $request->position;
       $uF->field_id = $id;
       $uF->addedby_id = Auth::id();
       $uF->save();

       return back()->with('message',"Option Created Successfully.");
    }
    public function optionItemEdit($id)
    {
       $userSettingsItem = UserSettingItem::find($id);
       return view('admin.option.edit',compact('userSettingsItem'));
    }

    public function optionItemUpdate(Request $request,$id)
    {
       
        $request->validate([
            'title' => 'required'
           ]);
    
           $uF = UserSettingItem::find($id);
           $uF->title = $request->title;
           $uF->drag_id = $request->position;
           $uF->field_id = $request->field_id;
           $uF->editedby_id = Auth::id();
           $uF->save();
           return redirect()->route('optionsSettings.index')->with('message',"Option Updated Successfully.");
    }
    public function optionItemDelete($id)
    {
        $uF = UserSettingItem::find($id)->delete();
        return redirect()->route('optionsSettings.index')->with('message',"Option Deleted Successfully.");
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
