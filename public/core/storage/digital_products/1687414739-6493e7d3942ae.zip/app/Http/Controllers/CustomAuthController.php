<?php

namespace App\Http\Controllers;

use App\Models\Cast;
use Illuminate\Http\Request;
use Hash;
use App\Mail\RegMail;
use App\Models\District;
use App\Models\Division;
use App\Models\Religion;
// use App\Models\Cast;
use Illuminate\Support\Facades\Mail;
use App\Models\Upazila;
use Session;
use App\Models\User;
use App\Models\WebsiteParameter;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session as FacadesSession;
use Illuminate\Support\Facades\Validator;
use Toastr;

class CustomAuthController extends Controller
{

  public function __construct()
  {
    if (!Auth::check()) {
      return view('auth.login');
    } else {
      return redirect('/');
    }
    
  }


  public function test()
  {

    return view("test");
  }
  public function aboutUs()
  {

    return view("aboutUs");
  }

  public function userLogin(Request $request)
  {
    if (!Auth::check()) {

      return view('auth.login');
    } else {

      return redirect('/');
    }
  }

  public function customRegistration(Request $request)
  {
    $request->validate([
      'email' => 'required|email|unique:users,email',
      'password' => 'required|min:6',
      'password_confirmation' => 'required_with:password|same:password|min:6'
    ]);

    $latest_user = User::latest()->first();

    $latest_username = $latest_user->username;
    $uyear = substr($latest_user->username, 0, 2);
    if ($latest_user) {
      if ($uyear == date('y')) {
        $un = $latest_username + 1;
      } else {
        $un = date('y') * 100000 + 1;
      }
    } else {
      $un = date('y') * 100000 + 1;
    }

    $data = $request->all();

    $user = $this->create($data);
    $user->update([
      'password_temp' => $request->password,
      'username' => $un,
      'active'  => true
    ]);



    $user->registerSmsSend();

    $details = [
      'title' => "New Registration",
    ];
    Auth::login($user);

    return redirect()->route('register')->with('message', 'Account created successfully');
  }


  public function create(array $data)
  {
    return User::create([
      'mobile' => $data['full_mobile'],
      'email' => $data['email'],
      'password' => Hash::make($data['password'])
    ]);
  }


  public function customLogin(Request $request)
  {

    if($request->ajax()){
      $rules = [
        'email' => 'required',
        'password' => 'required',
      ];
  
      $validator = Validator::make($request->all(), $rules);
      if ($validator->fails()) {
        $errmsgs = $validator->getMessageBag()->add('error', 'true');
        return response()->json($validator->errors());
      }
  
  
      $credentials = $request->only('email', 'password');
      if (Auth::attempt($credentials)) {
  
        $user = auth()->user();
  
        if ($user->active == false) {
          Auth::logout();
          return back()->with("warning","Your Account Is Disable");
        }
  
  
        User::where('id', $user->id)->update([
          'loggedin_at' => Carbon::now()
        ]);
        // dd($user->name);
        if (is_null($user->name) || is_null($user->gender)  || is_null($user->religion)) {
          Toastr::warning('Please Complete Pertner Preference.');
  
          return response()->Json([
            'status' => "success",
            'message' => "Please Complete Profile !",
          ]);
  
        } elseif (!$user->pertnerPreference) {
  
          Toastr::warning('Please Complete Partner Preference');
          return response()->Json([
            'status' => "success",
            'message' => "Please Complete Partner Preference  !",
          ]);
  
        } else {
          Toastr::Success('Login Successfully!!');
          return response()->Json([
            'status' => "success",
            'message' => "Successfully Login !",
          ]);
        }
      }
  
      return response()->Json([
        'status' => "notValidate",
        'message' => "Email and Password Not Match !",
      ]);
    }else{

      $rules = [
        'email' => 'required',
        'password' => 'required',
      ];
  
      $validator = Validator::make($request->all(), $rules);
      if ($validator->fails()) {
        return back()->withErrors($validator)
        ->withInput()
        ->with('error', 'Something went wrong.');
      }
  
  
      $credentials = $request->only('email', 'password');
      if (Auth::attempt($credentials)) {
        $user = auth()->user();
  
        if ($user->active == false) {
          Auth::logout();
          return back()->with("warning","Your Account Is Disable");
        }
  
  
        User::where('id', $user->id)->update([
          'loggedin_at' => Carbon::now()
        ]);
        session()->flash('message','Successfully Login');
        return redirect()->route('welcome');
          
        }

        session()->flash('warning','Email & password Not Match');
        return back();
    }


  }


  public function signOut()
  {
    Session::flush();
    Auth::logout();

    return Redirect('/');
  }

  //step -2

  public function register()
  {


    $me = Auth::user();
    if($me->gender && $me->dob && $me->religion){
      return redirect()->route('user.physical')->with('success','Already Complete step-2');
    }

    $religions = Religion::get();
    $districts = District::get();
    return view('registration', compact('religions','districts'));
  }

//step-3
  public function physicalAttribute()
  {
    $me = Auth::user();
    if($me->gradient_name || $me->relation_with_contact){
      return redirect()->route('register.step7')->with('succcess','Already Complete step-3');
    }
    return view('registar.physicalAttribute');
  }
  //step -4

  public function registerStep4()
  {
   return view('registar.register-step4');
  }
  public function registerStep5()
  {
    return view('registar.register-step5');
  }
  public function registerStep6()
  {
    return view('registar.register-step6');
  }
  public function registerStep7()
  {
    $userId = Auth::id();
    $me = User::find($userId);
  
    if($me->pertnerPreference){
      return redirect()->route('register.step8');
    }


     return view('registar.register-step7');
  }
  public function registerStep8()
  {
    $userId = Auth::id();
    $me = User::find($userId);
    if($me->userProfilePics()->count() > 1){
      return redirect()->route('welcome');
    }

     return view('registar.register-step8');
  }

  public function registerStep9()
  {
    return view('registar.register-step9');
  }
 


  public function socialCulture()
  {
    //   dd('ok');

    return view('registar.socialCulture');
  }

  public function familyInfo()
  {
    //   dd('ok');

    return view('registar.familyInfo');
  }

  public function contactInfo()
  {
    
    $divisions = Division::orderBy('name')->get();
    $districts = District::orderBy('name')->get();
    // dd($districts);
    $thanas = Upazila::orderBy('name')->get();
    // dd($divisions, $districts, $thanas  );

    return view('registar.contactInfo', compact('divisions', 'districts', 'thanas'));
  }

  public function lifestyleInfo()
  {
    //   dd('ok');

    return view('registar.lifestyleInfo');
  }



  public function pertnerForm()
  {
    $religions = Religion::get();
    return view('pertnerForm', compact('religions'));
  }
}
