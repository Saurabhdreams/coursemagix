<?php

namespace App\Http\Controllers;

use App\Models\GatewaySetting;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use File;

class GatewayController extends Controller
{

    public function allGateway(Request $request)
    {
       request()->session()->forget(['lsbm', 'lsbsm']);
       request()->session()->put(['lsbm' => 'payments', 'lsbsm' => 'gateway']);
       $gateways = GatewaySetting::get();
       
       return view('admin.gateway.index',compact('gateways'));
   
    }

    public function createGatway()
    {
        request()->session()->forget(['lsbm', 'lsbsm']);
        request()->session()->put(['lsbm' => 'payments', 'lsbsm' => 'gateway']);
        return view('admin.gateway.create');
    }
    public function gatewayPost(Request $request)
    {

       $request->validate([
        'active'=>'required',
        'gatewayStep'=>'required',
        'gatewayName'=>'required',
       ]);

       $gt = new GatewaySetting();
       $gt->gateway_name = $request->gatewayName;
       $gt->gateway_step = $request->gatewayStep;

       if ($request->hasFile('image')) {
        $file = $request->file('image');
        $extension = strtolower($file->getClientOriginalExtension());
        $originalName = rand(1111, 9999) . '.' . $extension;
        Storage::disk('upload')->put('img/'. $originalName, File::get($file));
       $gt->image =  $originalName;
    }


       $gt->active = $request->active == 'active' ? true:false;
       $gt->save();
       return redirect()->route('admin.allGateway')->with('success'.'Gateway option Crated successfully.');
    }

    public function gatewayEdit (GatewaySetting $gateway)
    {
        request()->session()->forget(['lsbm', 'lsbsm']);
        request()->session()->put(['lsbm' => 'payments', 'lsbsm' => 'gateway']);
    
        return view('admin.gateway.edit',compact('gateway'));

    }

    public function gatewayUpdate(Request $request,GatewaySetting $gateway)
    {


       $request->validate([
        'active'=>'required',
        'gatewayStep'=>'required',
        'gatewayName'=>'required',
       ]);

       $gt = $gateway;
       $gt->gateway_name = $request->gatewayName;
       $gt->gateway_step = $request->gatewayStep;

       if ($request->hasFile('image')) {
        $file = $request->file('image');
        $extension = strtolower($file->getClientOriginalExtension());
        $originalName = rand(1111, 9999) . '.' . $extension;
        Storage::disk('upload')->put('img/'. $originalName, File::get($file));
       $gt->image =  $originalName;
    }


       $gt->active = $request->active == 'active' ? true:false;
       $gt->save();

       return redirect()->route('admin.allGateway')->with('success'.'Gateway option Update successfully.');
    }

}
