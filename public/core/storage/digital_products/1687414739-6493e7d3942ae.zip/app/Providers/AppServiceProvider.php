<?php

namespace App\Providers;

use Illuminate\Support\Facades\Cache;
use App\Models\WebsiteParameter;
use App\Models\User;
use App\Models\Page;
use App\Models\Contact;
use App\Models\UserSettingField;
use Auth;
use View;
use Illuminate\Pagination\Paginator;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Paginator::useBootstrap();
        //
        $wb =  WebsiteParameter::latest()->first();
        view()->share('websiteParameter', $wb);


        $countUnseen = Contact::where('seen_status', false)->count();
        view()->share('countUnseen', $countUnseen);
        view()->share('menupages', Page::orderBy('page_title')->whereActive(true)->whereListInMenu(true)->get());
        
        if (env('APP_ENV') == 'production') {
            $usf = UserSettingField::all();
            view()->share('userSettingFields', $usf);
            // }
        } elseif (env('APP_ENV') == 'local') {
            $usf = UserSettingField::all();
            view()->share('userSettingFields',$usf);
        }
    }
}
